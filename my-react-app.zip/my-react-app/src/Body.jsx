function Body(){

    return(
        <div className="body-container">
            <h1>The meal kit that puts quality first</h1>
            <button className="discount-button">GET 2,500 TZS OFF NOW</button>
        </div>
    );
}

export default Body